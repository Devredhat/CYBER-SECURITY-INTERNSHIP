import requests
import random

# ---------------- CONFIG ----------------
INPUT_FILE = "all_proxies.txt"       # contains all proxies: IP:PORT per line
WORKING_FILE = "working_proxies.txt"
DEAD_FILE = "dead_proxies.txt"
TEST_URL = "http://httpbin.org/ip"  # test URL
TIMEOUT = 5                         # seconds

# ---------------- LOAD PROXIES ----------------
with open(INPUT_FILE, "r") as f:
    proxies_list = [line.strip() for line in f if line.strip()]

working = []
dead = []

print(f"Testing {len(proxies_list)} proxies...\n")

# ---------------- TEST EACH PROXY ----------------
for proxy in proxies_list:
    proxy_dict = {
        "http": f"http://{proxy}",
        "https": f"http://{proxy}"
    }
    try:
        r = requests.get(TEST_URL, timeout=TIMEOUT, proxies=proxy_dict)
        if r.status_code == 200:
            print(f"[✅ WORKING] {proxy} -> IP seen: {r.json().get('origin')}")
            working.append(proxy)
        else:
            print(f"[❌ FAILED] {proxy} -> Status code: {r.status_code}")
            dead.append(proxy)
    except Exception as e:
        print(f"[❌ FAILED] {proxy} -> {e}")
        dead.append(proxy)

# ---------------- WRITE RESULTS ----------------
with open(WORKING_FILE, "w") as f:
    for p in working:
        f.write(p + "\n")

with open(DEAD_FILE, "w") as f:
    for p in dead:
        f.write(p + "\n")

print(f"\n✅ Done! Working: {len(working)}, Dead: {len(dead)}")
print(f"Working proxies saved to {WORKING_FILE}")
print(f"Dead proxies saved to {DEAD_FILE}")
